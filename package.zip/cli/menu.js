import inquirer from "inquirer";
import chalk from "chalk";
import { loadTasks, saveTasks, loadData, saveData } from "../utils/storage.js";
import { classifyTaskAI } from "../utils/ai.js";
import Task from "../models/task.js";
import dayjs from "dayjs";

const printSeparator = () =>
  console.log(chalk.magenta("\n────────────────────────────────────────\n"));

// ➕ Add a Task
const addTask = async () => {
  console.clear();
  const tasks = await loadTasks();
  const data = await loadData(); // Load saved categories & people

  printSeparator();
  console.log(chalk.bold.green("✨ Add a New Task"));
  printSeparator();

  const taskInput = await inquirer.prompt([
    { name: "title", message: chalk.cyan("📝 Task Title:") },
    { name: "description", message: chalk.cyan("📄 Task Description:") },
  ]);

  // ✅ Select or Create Assigned Person
  const { assignedTo } = await inquirer.prompt([
    {
      type: "list",
      name: "assignedTo",
      message: chalk.cyan("👤 Assign to:"),
      choices: [...data.people, "➕ Add New Person"],
    },
  ]);

  let finalAssignedTo = assignedTo;
  if (assignedTo === "➕ Add New Person") {
    const { newPerson } = await inquirer.prompt([
      { name: "newPerson", message: chalk.cyan("👤 Enter new person's name:") },
    ]);
    finalAssignedTo = newPerson;
    data.people.push(newPerson);
  }

  // ✅ Select or Create Category
  const { category } = await inquirer.prompt([
    {
      type: "list",
      name: "category",
      message: chalk.cyan("📂 Select Category:"),
      choices: [...data.categories, "➕ Add New Category"],
    },
  ]);

  let finalCategory = category;
  if (category === "➕ Add New Category") {
    const { newCategory } = await inquirer.prompt([
      {
        name: "newCategory",
        message: chalk.cyan("📂 Enter new category name:"),
      },
    ]);
    finalCategory = newCategory;
    data.categories.push(newCategory);
  }

  // ✅ Save updated categories & people
  await saveData(data);

  // ✅ Deadline Input
  const { deadline } = await inquirer.prompt([
    {
      name: "deadline",
      message: chalk.cyan(
        "⏳ Deadline (e.g., 'tomorrow 15:30', 'next Monday 10:00'):"
      ),
    },
  ]);

  console.log(chalk.blue("\n🤖 AI analyzing task & correcting spelling..."));

  try {
    const aiResult = await classifyTaskAI(
      taskInput.title,
      taskInput.description,
      deadline
    );

    const newTask = new Task(
      aiResult.correctedTitle,
      aiResult.correctedDescription,
      finalAssignedTo,
      aiResult.deadline,
      aiResult.priority,
      [finalCategory]
    );

    tasks.push(newTask);
    await saveTasks(tasks);

    printSeparator();
    console.log(chalk.green("✅ Task Added Successfully!"));
    console.log(
      chalk.yellow(
        `📂 Category: ${finalCategory} | 🔥 Priority: ${aiResult.priority}`
      )
    );
    console.log(chalk.magenta(`⏳ Deadline: ${aiResult.deadline}`));
    printSeparator();

    await inquirer.prompt([
      {
        name: "continue",
        message: chalk.gray("Press ENTER to return to menu"),
        type: "input",
      },
    ]);
  } catch (error) {
    console.log(chalk.red("❌ Error adding task:", error));
  }
};

// 📝 Edit a Task
const editTask = async () => {
  console.clear();
  const tasks = await loadTasks();
  const data = await loadData();

  if (tasks.length === 0) {
    console.log(chalk.yellow("\n🚨 No tasks available to edit."));
    return;
  }

  printSeparator();
  console.log(chalk.bold.yellow("✏️ Edit a Task"));
  printSeparator();

  const { taskIndex } = await inquirer.prompt([
    {
      type: "list",
      name: "taskIndex",
      message: chalk.cyan("🔢 Select task to edit:"),
      choices: tasks.map((task, index) => `${index + 1}. ${task.title}`),
    },
  ]);

  const index = parseInt(taskIndex.split(".")[0]) - 1;
  const task = tasks[index];

  const updatedTaskInput = await inquirer.prompt([
    {
      name: "title",
      message: chalk.cyan(`📝 Task Title (${task.title}):`),
      default: task.title,
    },
    {
      name: "description",
      message: chalk.cyan(`📄 Task Description (${task.description}):`),
      default: task.description,
    },
  ]);

  // ✅ Select or Create Assigned Person
  const { assignedTo } = await inquirer.prompt([
    {
      type: "list",
      name: "assignedTo",
      message: chalk.cyan("👤 Assign to:"),
      choices: [...data.people, "➕ Add New Person"],
      default: task.assignedTo,
    },
  ]);

  let finalAssignedTo = assignedTo;
  if (assignedTo === "➕ Add New Person") {
    const { newPerson } = await inquirer.prompt([
      { name: "newPerson", message: chalk.cyan("👤 Enter new person's name:") },
    ]);
    finalAssignedTo = newPerson;
    data.people.push(newPerson);
  }

  // ✅ Select or Create Category
  const { category } = await inquirer.prompt([
    {
      type: "list",
      name: "category",
      message: chalk.cyan("📂 Select Category:"),
      choices: [...data.categories, "➕ Add New Category"],
      default: task.categories[0],
    },
  ]);

  let finalCategory = category;
  if (category === "➕ Add New Category") {
    const { newCategory } = await inquirer.prompt([
      {
        name: "newCategory",
        message: chalk.cyan("📂 Enter new category name:"),
      },
    ]);
    finalCategory = newCategory;
    data.categories.push(newCategory);
  }

  // ✅ Save updated categories & people
  await saveData(data);

  // ✅ Deadline Input
  const { deadline } = await inquirer.prompt([
    {
      name: "deadline",
      message: chalk.cyan(`⏳ Deadline (${task.deadline}):`),
      default: task.deadline,
    },
  ]);

  console.log(chalk.blue("\n🤖 AI analyzing task & correcting spelling..."));

  try {
    const aiResult = await classifyTaskAI(
      updatedTaskInput.title,
      updatedTaskInput.description,
      deadline
    );

    tasks[index] = new Task(
      aiResult.correctedTitle,
      aiResult.correctedDescription,
      finalAssignedTo,
      aiResult.deadline,
      aiResult.priority,
      [finalCategory]
    );

    await saveTasks(tasks);

    printSeparator();
    console.log(chalk.green("✅ Task Updated Successfully!"));
    printSeparator();

    await inquirer.prompt([
      {
        name: "continue",
        message: chalk.gray("Press ENTER to return to menu"),
        type: "input",
      },
    ]);
  } catch (error) {
    console.log(chalk.red("❌ Error updating task:", error));
  }
};

// 📋 List Tasks
const listTasks = async () => {
  console.clear();
  const tasks = await loadTasks();

  if (tasks.length === 0) {
    console.log(chalk.yellow("\n🚨 No tasks available."));
  } else {
    printSeparator();
    console.log(chalk.bold.blue("📋 Task List"));
    printSeparator();

    const now = dayjs();

    tasks.forEach((task, index) => {
      const deadline = dayjs(task.deadline);
      const daysLeft = deadline.diff(now, "day");
      let deadlineColor = chalk.green;
      let urgencyLabel = "🟢 On Time";

      if (daysLeft < 0) {
        deadlineColor = chalk.red.bold;
        urgencyLabel = "⚠️ OVERDUE";
      } else if (daysLeft < 3) {
        deadlineColor = chalk.red.bold;
        urgencyLabel = "🔴 URGENT";
      } else if (daysLeft < 7) {
        deadlineColor = chalk.yellow.bold;
        urgencyLabel = "🟡 Due Soon";
      }

      console.log(
        `${chalk.cyan(`#${index + 1}`)} ${chalk.white.bold(
          task.title
        )}  ${chalk.gray("- " + task.assignedTo)}\n` +
          `   📂 ${chalk.magenta(task.categories[0])} | 🔥 ${chalk.yellow(
            task.priority.toUpperCase()
          )} | ` +
          `⏳ ${deadlineColor(
            deadline.format("YYYY-MM-DD HH:mm")
          )} (${urgencyLabel})\n`
      );
    });

    printSeparator();
  }

  await inquirer.prompt([
    {
      name: "continue",
      message: chalk.gray("Press ENTER to return to menu"),
      type: "input",
    },
  ]);
};

// 🗑️ Delete a Task with Confirmation
const deleteTask = async () => {
  console.clear();
  const tasks = await loadTasks();
  if (tasks.length === 0) {
    console.log(chalk.yellow("\n🚨 No tasks available to delete."));
    return;
  }

  printSeparator();
  console.log(chalk.bold.red("🗑️ Delete a Task"));
  printSeparator();

  const { taskIndex } = await inquirer.prompt([
    {
      type: "list",
      name: "taskIndex",
      message: chalk.cyan("🔢 Select task to delete:"),
      choices: tasks.map((task, index) => `${index + 1}. ${task.title}`),
    },
  ]);

  const index = parseInt(taskIndex.split(".")[0]) - 1;
  const task = tasks[index];

  // ✅ Confirm before deleting
  const { confirmDelete } = await inquirer.prompt([
    {
      type: "confirm",
      name: "confirmDelete",
      message: chalk.red(`⚠️ Are you sure you want to delete "${task.title}"?`),
      default: false,
    },
  ]);

  if (!confirmDelete) {
    console.log(chalk.yellow("❌ Task deletion cancelled."));
    return;
  }

  tasks.splice(index, 1);
  await saveTasks(tasks);
  console.log(chalk.green("\n✅ Task deleted successfully."));
};

const mainMenu = async () => {
  while (true) {
    console.clear();
    printSeparator();
    console.log(chalk.bold.red("📌 Task Manager"));
    printSeparator();

    const { action } = await inquirer.prompt([
      {
        type: "list",
        name: "action",
        message: chalk.yellow("📌 Choose an action:"),
        choices: [
          "➕  Add Task",
          "📋  List Tasks",
          "✏️  Edit Task",
          "🗑️  Delete Task",
          "❌  Exit",
        ],
      },
    ]);

    if (action === "➕  Add Task") await addTask();
    else if (action === "📋  List Tasks") await listTasks();
    else if (action === "✏️  Edit Task") await editTask();
    else if (action === "🗑️  Delete Task") await deleteTask();
    else break;
  }
};

export { mainMenu };
