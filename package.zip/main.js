import { mainMenu } from "./cli/menu.js";

mainMenu();
